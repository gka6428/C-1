# include <stdio.h>

int main(void)
{
    // do~while에 대한 실습; 최소한 1번의 반복문 시행이 필요할 경우에 쓰이는 명령어
    int total=0, num=0;
    do
    {
        printf("정수 입력(0 to quit): ");
        scanf_s("%d", &num);
        total += num;
    }while(num!=0);
    printf("합계: %d \n", total);
    return 0;
}