# include <stdio.h>

int main(void)
{
    // while문의 중첩에 대한 실습; for와의 연관성과 디버깅을 통한 이해
    int cur=2;
    int is=0;

    while(cur<10)
    {
        is=1;
        while(is<10)
        {
            printf("%d X %d = %d \n", cur, is, cur*is);
            is++;
        }
        cur++;
    }
    return 0;
}