# include <stdio.h>

int main(void)
{
    // while문에 대한 실습; while문은 반복문이다.
    int num=0;
    while(num<5)
    {
        printf("Hello World! %d \n", num);
        num++;
    }
    return 0;
}